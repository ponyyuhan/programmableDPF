// ================================================================
// File: src/prg/prg.cpp
// ================================================================

#include "pdpf/prg/prg.hpp"
#include <cstring>

namespace pdpf::prg {

AesCtrPrg::AesCtrPrg(const core::Seed &master_key)
    : master_key_(master_key) {
    // TODO: initialize AES key schedule / context using master_key_.
}

void AesCtrPrg::expand(const core::Seed &seed,
                       core::Seed &left,
                       core::Seed &right) const {
    // TODO: Implement G(seed) = AES-CTR(master_key_, seed) producing 2λ bits.
    // For example:
    //  - Treat seed as 128-bit IV.
    //  - Encrypt counter=0 → first 128 bits (left).
    //  - Encrypt counter=1 → second 128 bits (right).
    // Ensure constant-time implementation and secure IV usage.
    (void)seed;
    (void)left;
    (void)right;
    throw std::logic_error("AesCtrPrg::expand not implemented");
}

} // namespace pdpf::prg
