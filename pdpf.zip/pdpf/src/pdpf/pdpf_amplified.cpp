// ================================================================
// File: src/pdpf/pdpf_amplified.cpp
// ================================================================

#include "pdpf/pdpf/pdpf_amplified.hpp"
#include <stdexcept>

namespace pdpf::pdpf {

PdpfAmplified::PdpfAmplified(std::shared_ptr<prg::IPrg> prg,
                             const ldc::LdcParams &ldc_params,
                             std::uint64_t prime_p)
    : prg_(std::move(prg))
    , base_pdpf_(prg_)
    , ldc_(ldc_params)
    , prime_p_(prime_p) {
    if (prime_p_ == 0) {
        throw std::invalid_argument("PdpfAmplified: prime_p must be non-zero prime");
    }
}

core::Seed PdpfAmplified::derive_inner_seed(const core::Seed &master,
                                            std::uint64_t index) const {
    // TODO: Implement a simple KDF from master seed and index, e.g.:
    //   seed = G(master || index) using prg_.
    (void)master;
    (void)index;
    throw std::logic_error("PdpfAmplified::derive_inner_seed not implemented");
}

std::int64_t PdpfAmplified::mod_p(std::int64_t x) const {
    // TODO: robust modular reduction in Z_p.
    std::int64_t r = static_cast<std::int64_t>(x % static_cast<std::int64_t>(prime_p_));
    if (r < 0) r += static_cast<std::int64_t>(prime_p_);
    return r;
}

AmplifiedOfflineKey PdpfAmplified::gen_offline(const core::SecurityParams &sec) {
    AmplifiedOfflineKey k0;
    k0.sec       = sec;
    k0.ldc_params = ldc_.params();
    k0.prime_p   = prime_p_;

    core::RandomDevice rng;
    rng.random_seed(k0.master_seed);

    return k0;
}

AmplifiedOnlineKey PdpfAmplified::gen_online(const AmplifiedOfflineKey &k0,
                                             std::uint64_t alpha,
                                             std::int64_t beta) {
    (void)beta; // base PDPF here is binary; extension to Z_p is via Theorem 5 if needed.

    const auto &ldc_params = k0.ldc_params;
    std::uint64_t q = ldc_params.q;
    std::uint64_t L = ldc_params.L;

    // 1. Compute Δ ← d(α) ∈ [L]^q.
    auto Delta = ldc_.sample_indices(alpha);

    if (Delta.size() != q) {
        throw std::runtime_error("PdpfAmplified::gen_online: wrong Δ size");
    }

    AmplifiedOnlineKey k1;
    k1.sec        = k0.sec;
    k1.ldc_params = ldc_params;
    k1.prime_p    = prime_p_;
    k1.inner_keys.reserve(q);

    // 2. For each ℓ = 1..q:
    //    - derive k*_ℓ from master_seed
    //    - form OfflineKey for base PDPF over domain L (here domain size is L)
    //    - run base_pdpf_.gen_online for target index Δ_ℓ.
    core::SecurityParams inner_sec = k0.sec;
    inner_sec.domain_size_N = L;

    for (std::uint64_t i = 0; i < q; ++i) {
        core::Seed inner_seed = derive_inner_seed(k0.master_seed, i);
        OfflineKey inner_off;
        inner_off.k_star = inner_seed;
        inner_off.params.sec = inner_sec;
        inner_off.params.M   = 0; // TODO: choose_M for inner PDPF based on L and epsilon.

        // Binary payload β=1 at index Δ_i (see Figure 2). :contentReference[oaicite:23]{index=23}
        OnlineKey inner_on = base_pdpf_.gen_online(inner_off, Delta[i], 1);
        k1.inner_keys.push_back(std::move(inner_on));
    }

    return k1;
}

std::int64_t PdpfAmplified::eval_offline(const AmplifiedOfflineKey &k0,
                                         const AmplifiedOnlineKey &k1,
                                         std::uint64_t x) const {
    const auto &ldc_params = k0.ldc_params;
    std::uint64_t q = ldc_params.q;
    std::uint64_t L = ldc_params.L;

    // Encode unit vector e_x into C(e_x) ∈ Z_p^L.
    std::vector<std::int64_t> C_ex(L);
    // TODO: implement ldc_.encode_unit(x, C_ex) over Z_p.
    (void)x;
    (void)C_ex;
    (void)q;
    (void)k1;
    throw std::logic_error("PdpfAmplified::eval_offline not implemented");
}

std::int64_t PdpfAmplified::eval_online(const AmplifiedOfflineKey &k0,
                                        const AmplifiedOnlineKey &k1,
                                        std::uint64_t x) const {
    // TODO: symmetric to eval_offline, but using EvalAll1 on inner PDPFs.
    (void)k0;
    (void)k1;
    (void)x;
    throw std::logic_error("PdpfAmplified::eval_online not implemented");
}

void PdpfAmplified::eval_all_offline(const AmplifiedOfflineKey &k0,
                                     const AmplifiedOnlineKey &k1,
                                     std::vector<std::int64_t> &Y0) const {
    // TODO: full-domain evaluation: for each x, compute eval_offline(k0,k1,x).
    (void)k0;
    (void)k1;
    (void)Y0;
    throw std::logic_error("PdpfAmplified::eval_all_offline not implemented");
}

void PdpfAmplified::eval_all_online(const AmplifiedOfflineKey &k0,
                                    const AmplifiedOnlineKey &k1,
                                    std::vector<std::int64_t> &Y1) const {
    // TODO: full-domain evaluation: for each x, compute eval_online(k0,k1,x).
    (void)k0;
    (void)k1;
    (void)Y1;
    throw std::logic_error("PdpfAmplified::eval_all_online not implemented");
}

} // namespace pdpf::pdpf
