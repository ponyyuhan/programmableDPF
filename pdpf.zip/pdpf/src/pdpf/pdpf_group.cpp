// ================================================================
// File: src/pdpf/pdpf_group.cpp
// ================================================================

#include "pdpf/pdpf/pdpf_group.hpp"
#include <stdexcept>

namespace pdpf::pdpf {

PdpfGroup::PdpfGroup(std::shared_ptr<prg::IPrg> prg)
    : prg_(std::move(prg)),
      base_pdpf_(prg_) {}

std::size_t PdpfGroup::infer_payload_bits(const core::GroupDescriptor &group) const {
    // TODO: choose payload_bits from |G'| or from max modulus.
    // For example: sum log2(q_i) for finite components.
    if (group.moduli.empty()) {
        // G = Z, choose some upper bound externally.
        throw std::runtime_error("PdpfGroup::infer_payload_bits: ambiguous for Z");
    }
    std::size_t bits = 0;
    for (auto q : group.moduli) {
        if (q == 0) {
            throw std::runtime_error("PdpfGroup::infer_payload_bits: infinite component present");
        }
        std::size_t b = 0;
        std::uint64_t x = q - 1;
        while (x > 0) { x >>= 1; ++b; }
        bits += b;
    }
    return bits;
}

PdpfGroupOfflineKey PdpfGroup::gen_offline(const core::SecurityParams &sec,
                                           const core::GroupDescriptor &group,
                                           std::size_t payload_bits) {
    PdpfGroupOfflineKey k0;
    k0.group_desc = group;
    k0.sec        = sec;

    if (payload_bits == 0) {
        payload_bits = infer_payload_bits(group);
    }

    k0.bit_offline_keys.clear();
    k0.bit_offline_keys.reserve(payload_bits);
    for (std::size_t i = 0; i < payload_bits; ++i) {
        k0.bit_offline_keys.push_back(base_pdpf_.gen_offline(sec));
    }
    return k0;
}

std::vector<std::uint8_t> PdpfGroup::encode_payload(const core::GroupDescriptor &group,
                                                    const core::GroupElement &beta,
                                                    std::size_t payload_bits) const {
    // TODO: Implement group-element → bit-vector encoding, consistent with Theorem 5. :contentReference[oaicite:17]{index=17}
    (void)group;
    (void)beta;
    (void)payload_bits;
    throw std::logic_error("PdpfGroup::encode_payload not implemented");
}

core::GroupElement PdpfGroup::decode_payload(const core::GroupDescriptor &group,
                                             const std::vector<std::int64_t> &bit_values,
                                             std::size_t payload_bits) const {
    // TODO: Implement inverse of encode_payload.
    (void)group;
    (void)bit_values;
    (void)payload_bits;
    throw std::logic_error("PdpfGroup::decode_payload not implemented");
}

PdpfGroupOnlineKey PdpfGroup::gen_online(const PdpfGroupOfflineKey &k0,
                                         std::uint64_t alpha,
                                         const core::GroupElement &beta) {
    const std::size_t payload_bits = k0.bit_offline_keys.size();
    auto bits = encode_payload(k0.group_desc, beta, payload_bits);
    if (bits.size() != payload_bits) {
        throw std::runtime_error("PdpfGroup::gen_online: bit encoding size mismatch");
    }

    PdpfGroupOnlineKey k1;
    k1.group_desc = k0.group_desc;
    k1.sec        = k0.sec;
    k1.bit_online_keys.reserve(payload_bits);

    for (std::size_t i = 0; i < payload_bits; ++i) {
        std::uint8_t b = bits[i] & 1u;
        const OfflineKey &bit_off = k0.bit_offline_keys[i];
        k1.bit_online_keys.push_back(base_pdpf_.gen_online(bit_off, alpha, b));
    }

    return k1;
}

void PdpfGroup::eval_all_offline(const PdpfGroupOfflineKey &k0,
                                 std::vector<core::GroupElement> &Y) const {
    const std::uint64_t N = k0.sec.domain_size_N;
    const std::size_t payload_bits = k0.bit_offline_keys.size();

    // Y_bit[i][x] = share for bit i at position x.
    std::vector<std::vector<core::GroupZ::Value>> Y_bits(payload_bits);

    for (std::size_t i = 0; i < payload_bits; ++i) {
        base_pdpf_.eval_all_offline(k0.bit_offline_keys[i], Y_bits[i]);
    }

    Y.assign(N, core::group_zero(k0.group_desc));

    // TODO: Reconstruct group element per x using decode_payload and per-bit counts.
    // For each x:
    //   - gather bit_values[i] = Y_bits[i][x]
    //   - interpret counts as {0,1} and decode β.
    (void)Y_bits;
    throw std::logic_error("PdpfGroup::eval_all_offline not fully implemented");
}

void PdpfGroup::eval_all_online(const PdpfGroupOnlineKey &k1,
                                std::vector<core::GroupElement> &Y) const {
    const std::uint64_t N = k1.sec.domain_size_N;
    const std::size_t payload_bits = k1.bit_online_keys.size();

    std::vector<std::vector<core::GroupZ::Value>> Y_bits(payload_bits);

    for (std::size_t i = 0; i < payload_bits; ++i) {
        base_pdpf_.eval_all_online(k1.bit_online_keys[i], Y_bits[i]);
    }

    Y.assign(N, core::group_zero(k1.group_desc));

    // TODO: Same as eval_all_offline: per x, decode group element from bit-wise shares.
    (void)Y_bits;
    throw std::logic_error("PdpfGroup::eval_all_online not fully implemented");
}

} // namespace pdpf::pdpf
