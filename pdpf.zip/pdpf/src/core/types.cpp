// ================================================================
// File: src/core/types.cpp
// ================================================================

#include "pdpf/core/types.hpp"

namespace pdpf::core {

RandomDevice::RandomDevice() : rd_() {}

void RandomDevice::random_seed(Seed &seed) {
    // TODO: replace with a robust CSPRNG (e.g. /dev/urandom + AES-CTR, or OS API).
    for (auto &b : seed) {
        b = static_cast<std::uint8_t>(rd_());
    }
}

std::uint64_t RandomDevice::random_u64(std::uint64_t bound) {
    if (bound == 0) {
        throw std::invalid_argument("RandomDevice::random_u64: bound = 0");
    }
    // TODO: implement rejection sampling to avoid modulo bias.
    std::uint64_t x = (static_cast<std::uint64_t>(rd_()) << 32) ^ rd_();
    return x % bound;
}

} // namespace pdpf::core
