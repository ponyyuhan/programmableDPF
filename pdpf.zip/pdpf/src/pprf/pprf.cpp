// ================================================================
// File: src/pprf/pprf.cpp
// ================================================================

#include "pdpf/pprf/pprf.hpp"
#include <cmath>
#include <stdexcept>

namespace pdpf::pprf {

Pprf::Pprf(std::shared_ptr<prg::IPrg> prg)
    : prg_(std::move(prg)) {}

/**
 * Compute depth d = ceil(log2(M)).
 */
std::uint32_t Pprf::tree_depth(std::uint64_t M) const {
    if (M == 0) {
        throw std::invalid_argument("Pprf::tree_depth: M = 0");
    }
    std::uint32_t d = 0;
    std::uint64_t x = 1;
    while (x < M) {
        x <<= 1;
        ++d;
    }
    return d;
}

void Pprf::seed_to_children(const core::Seed &parent,
                            core::Seed &left,
                            core::Seed &right) const {
    prg_->expand(parent, left, right);
}

std::uint64_t Pprf::seed_to_uint64(const core::Seed &seed) const {
    // TODO: define a stable mapping from 128-bit seed → 64-bit integer.
    // E.g. take the first 8 bytes in little-endian.
    (void)seed;
    throw std::logic_error("Pprf::seed_to_uint64 not implemented");
}

std::uint64_t Pprf::eval(const PprfKey &k, std::uint64_t x) const {
    // TODO: Implement GGM PRF evaluation:
    //  - depth d = ceil(log2(M))
    //  - treat x as d-bit binary string
    //  - iterate from root_seed, expanding via prg_->expand at each level
    //  - final leaf seed → uint64 → reduce mod N.
    if (x >= k.params.M) {
        throw std::out_of_range("Pprf::eval: x >= M");
    }
    (void)k;
    (void)x;
    throw std::logic_error("Pprf::eval not implemented");
}

void Pprf::eval_all(const PprfKey &k,
                    std::vector<std::uint64_t> &out) const {
    // TODO: Implement full GGM tree evaluation as in Theorem 3:
    //  - compute all seeds in a binary tree of size 2M−1
    //  - map leaves to [N].
    (void)k;
    (void)out;
    throw std::logic_error("Pprf::eval_all not implemented");
}

PprfPuncturedKey Pprf::puncture(const PprfKey &k, std::uint64_t xp) const {
    if (xp >= k.params.M) {
        throw std::out_of_range("Pprf::puncture: xp >= M");
    }
    PprfPuncturedKey kp;
    kp.params = k.params;
    kp.xp = xp;

    // TODO: Implement co-path key extraction for GGM tree:
    //  - walk path from root to leaf xp
    //  - at each level, compute both children
    //  - store sibling seed in kp.co_path_seeds.
    (void)k;

    return kp;
}

std::uint64_t Pprf::punc_eval(const PprfPuncturedKey &kp,
                              std::uint64_t x) const {
    if (x >= kp.params.M) {
        throw std::out_of_range("Pprf::punc_eval: x >= M");
    }
    if (x == kp.xp) {
        return PUNCTURED_SENTINEL;
    }
    // TODO: Reconstruct required seeds from co_path_seeds and PRG,
    //       skipping the punctured leaf.
    (void)kp;
    (void)x;
    throw std::logic_error("Pprf::punc_eval not implemented");
}

void Pprf::punc_eval_all(const PprfPuncturedKey &kp,
                         std::vector<std::uint64_t> &out) const {
    out.assign(kp.params.M, 0);
    for (std::uint64_t x = 0; x < kp.params.M; ++x) {
        out[x] = punc_eval(kp, x);
    }
}

} // namespace pdpf::pprf
